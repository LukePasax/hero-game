# ControllerInputViewer
A plugin for Godot 4 that allow you see and test your Inputs.
